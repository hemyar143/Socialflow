# Sociflow Frontend

## Setup

1. Copy `.env.local.example` to `.env.local`
2. Install deps: `npm install`
3. Run dev: `npm run dev`

## Deploy to Vercel

- Import to Vercel
- Set env vars
- Deploy!